import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {
		
		Cliente c1 = new Cliente();
		
		c1.setNome("Karen");
		c1.setTelefone("23452924");
		c1.setEmail("KarenBC@gmail.com");
		
		
		Imovel i1 = new Imovel();
		
		i1.setProprietario(c1);
		i1.setEndereco("S�o Paulo");
		i1.setValorImovel(2000.00);
		i1.setValorAluguel(400.00);
		i1.setaVenda(false);
		i1.setDisponivel(true);
		
		JOptionPane.showMessageDialog(null, i1.identificar() );
	}

}
