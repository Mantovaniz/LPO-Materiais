package br.com.imobiliaria.model;

public class Rural extends Imovel {

	private double hectares;

	
	public Rural(Cliente proprietario, String endereco, double valorImovel, double valorAluguel, boolean aVenda,
			boolean disponivel, String cond, String cond2, double hectares) {
		super(proprietario, endereco, valorImovel, valorAluguel, aVenda, disponivel, cond, cond2);
		this.hectares = hectares;
	}
	
	Rural () {
		this.hectares = 0;
	}

	
	public double getHectares() {
		return hectares;
	}

	public void setHectares(double hectares) {
		this.hectares = hectares;
	}
	
	
	public String identificar() {
		return "Nome do propriet�rio: " + this.getProprietario().getNome()  + "\nA venda: " + (this.isaVenda() ? "Sim" : "N�o") + "\nDispon�vel: " + (this.isDisponivel() ? "Sim" : "N�o");
	}
	
	
	
	
}
