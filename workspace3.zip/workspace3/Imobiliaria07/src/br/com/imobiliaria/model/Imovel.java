package br.com.imobiliaria.model;

import javax.swing.JOptionPane;

public class Imovel {

		private Cliente proprietario;
		private String endereco;
		private double valorImovel;
		private double valorAluguel;
		private boolean aVenda;
		private boolean disponivel;
				
		public Imovel(Cliente proprietario, String endereco, double valorImovel, double valorAluguel, boolean aVenda,boolean disponivel, String cond, String cond2) {
			this.proprietario = proprietario;
			this.endereco = endereco;
			this.valorImovel = valorImovel;
			this.valorAluguel = valorAluguel;
			this.aVenda = aVenda;
			this.disponivel = disponivel;
			
		}
		
		Imovel(){
			this.proprietario = new Cliente();
			this.endereco = "";
			this.valorImovel = 0.0;
			this.valorAluguel = 0.0;
			this.aVenda = true;
			this.disponivel = true;
		}
		
		
		public Cliente getProprietario() {
			return proprietario;
		}
		public void setProprietario(Cliente proprietario) {
			this.proprietario = proprietario;
		}
		public String getEndereco() {
			return endereco;
		}
		public void setEndereco(String endereco) {
			this.endereco = endereco;
		}
		public double getValorImovel() {
			return valorImovel;
		}
		public void setValorImovel(double valorImovel) {
			if (valorImovel>0.0){ this.valorImovel = valorImovel;
			}
			else {
			JOptionPane.showMessageDialog(null,"Valor negativo inserido em Valor do im�vel!");
			}
		}
		public double getValorAluguel() {
			return valorAluguel;
		}
		public void setValorAluguel(double valorAluguel) {
			if (valorAluguel>0.0){ this.valorAluguel = valorAluguel;	
			}
			else {
			JOptionPane.showMessageDialog(null,"Valor negativo inserido em valor do aluguel!");
			}
		}
		public boolean isaVenda() {	 
			return aVenda;
		}
		public void setaVenda(boolean aVenda) {
			this.aVenda= aVenda;
		}
		public boolean isDisponivel() {
			return disponivel;
		}
		public void setDisponivel(boolean disponivel) {
			this.disponivel= disponivel;
		}
		
}
