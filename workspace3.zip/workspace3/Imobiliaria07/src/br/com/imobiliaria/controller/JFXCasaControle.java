package br.com.imobiliaria.controller;

import java.net.URL;
import java.util.ResourceBundle;

import br.com.imobiliaria.model.Casa;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;


public class JFXCasaControle implements Initializable{

	Casa c1 = new Casa();

	@FXML Button bSair;
	@FXML TextField tfProprietario;
	@FXML TextField tfValorImovel;
	@FXML TextField tfValorAluguel;
	@FXML TextField tfEndereco;
	@FXML RadioButton rbAVenda;
	@FXML RadioButton rbDisponivel;
	@FXML ComboBox<String> cbSobrado;
	@FXML ComboBox<String> cbCondominio;
	@FXML Button bInserir;
	@FXML Button bIndentificar;
	@FXML Button bCarregar;
	@FXML Button bLimpar;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		tfProprietario.setText(String.valueOf(c1.getProprietario().getNome()));
		tfEndereco.setText(String.valueOf(c1.getEndereco()));
		tfValorImovel.setText(String.valueOf(c1.getValorImovel()));
		tfValorAluguel.setText(String.valueOf(c1.getValorAluguel()));
		cbSobrado.getItems().addAll("Sim","N�o");
		cbCondominio.getItems().addAll("Sim","N�o");
	}
	
	@FXML public void Inserir() {
		 c1.getProprietario().setNome(tfProprietario.getText());
		 c1.setValorImovel(Double.parseDouble(tfValorImovel.getText()));
		 c1.setValorAluguel(Double.parseDouble(tfValorAluguel.getText()));
		 c1.setEndereco(tfEndereco.getText());
		 if(cbSobrado.getValue() == "Sim") {
			 
			 c1.setSobrado(true);
		 }
		 else {
			 c1.setSobrado(false);
		 }
		 
		 if(cbCondominio.getValue() == "Sim") {
			 
			 c1.setCondominio(true);
			 }
			
		 else {
			 c1.setCondominio(false);
			 }
		 
	}
	
	@FXML public void Limpar() {
		tfProprietario.setText("");
		tfValorImovel.setText("");
		tfEndereco.setText("");
		cbSobrado.setValue("");
		cbCondominio.setValue("");
		rbAVenda.setSelected(false);
		rbDisponivel.setSelected(false);
	}	
	
	@FXML public void Carregar() {
		tfProprietario.setText(c1.getProprietario().getNome());
		tfValorAluguel.setText(String.valueOf(c1.getValorAluguel()));
		tfValorImovel.setText(String.valueOf(c1.getValorImovel()));
		tfEndereco.setText(c1.getEndereco());
		
		
		if(cbSobrado.getValue()== "Sim") {
			c1.setSobrado(true);
		}else {
			c1.setSobrado(false);
		}if(cbCondominio.getValue()== "Sim") {
			c1.setCondominio(true);
		}else {
			c1.setCondominio(false);
		}
	}
	
		@FXML public void Indentficar() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Casa");
		alert.setHeaderText("Identifica��o");
		alert.setContentText(c1.identificar());
		alert.showAndWait();
		
	}
	
	@FXML public void Sair() {
		System.exit(0);
	}

}
