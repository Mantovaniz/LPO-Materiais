import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {
		
		Disciplina d1 = new Disciplina();
		
		d1.setDescricao("LPOO");
		d1.setDocente("Ralfe");
		d1.setModalidade("Ensino M�dio");
		d1.setCargaHoraria(100);
		d1.setNota1(10);
		d1.setNota2(10);
		d1.setNota3(10);
		d1.setNota4(10);
		d1.setFrequencia(100);
				
		JOptionPane.showMessageDialog(null, d1.situacaoFinal());
	}

}
