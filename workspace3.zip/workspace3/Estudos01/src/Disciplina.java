import javax.swing.JOptionPane;

public class Disciplina {

	private String descricao;
	private String docente;
	private String modalidade;
	private double cargaHoraria;
	private double nota1;
	private double nota2;
	private double nota3;
	private double nota4;
	private int frequencia;
	private double media;
	
	public Disciplina(String descricao, String docente, String modalidade, double cargaHoraria) {
		this.descricao = descricao;
		this.docente = docente;
		this.modalidade = modalidade;
		this.cargaHoraria = cargaHoraria;
	}
	
	Disciplina(){
		this.descricao = "";
		this.docente = "";
		this.modalidade = "";
		this.cargaHoraria = 0.0;
		this.nota1 = 0.0;
		this.nota2 = 0.0;
		this.nota3 = 0.0;
		this.nota4 = 0.0;
		this.frequencia = 0;
		this.media=0.0;
	}

	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getDocente() {
		return docente;
	}
	public void setDocente(String docente) {
		this.docente = docente;
	}
	public String getModalidade() {
		return modalidade;
	}
	public void setModalidade(String modalidade) {
		this.modalidade = modalidade;
	}
	public double getCargaHoraria() {
		return cargaHoraria;
	}
	public void setCargaHoraria(double cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}
	public double getNota1() {
		return nota1;
	}
	public void setNota1(double nota1) {
	
		if(nota1==0.0 || nota1<=10.0) {this.nota1=nota1;
		}
		else {JOptionPane.showMessageDialog(null,"Valor inv�lido!");
		}
	}
	public double getNota2() {
		return nota2;
	}
	public void setNota2(double nota2) {
		
		if(nota2==0.0 || nota2<=10.0) {this.nota2=nota2;
		}
		else {JOptionPane.showMessageDialog(null,"Valor inv�lido!");
		}
	}
	public double getNota3() {
		return nota3;
	}
	public void setNota3(double nota3) {

		if(nota3==0.0 || nota3<=10.0) {this.nota3=nota3;
		}
		else {JOptionPane.showMessageDialog(null,"Valor inv�lido!");
		}
	}
	public double getNota4() {
		return nota4;
	}
	public void setNota4(double nota4) {
		
		if(nota4==0.0 || nota4<=10.0) {this.nota4=nota4;
		}
		else {
			JOptionPane.showMessageDialog(null,"Valor inv�lido!");
		}
	}
	public int getFrequencia() {
		return frequencia;
	}
	public void setFrequencia(int frequencia) {
		this.frequencia = frequencia;
		
		if(frequencia==0 || frequencia<=100) { this.frequencia= frequencia;
		}
		else {
			JOptionPane.showMessageDialog(null,"Frequ�ncia inv�lida!");
		}
		
	}
	
	private double calcularMedia() {	
		media=(nota1+nota2+nota3+nota4)/4;
		return  media;
	}
	
	public String situacaoFinal() {
		
		calcularMedia();
		
		if(media>=6.0 && frequencia>=75) { return "Nome: " + this.docente + "\nAprovado(a)!";
		}
		else if (media<6.0 && frequencia<75) { return "Nome: " + this.docente + "\nReprovado(a)";
		}
		else {return "Nome: " + this.docente + "\nReprovado(a) por frequ�ncia!";}
	}
	
}
