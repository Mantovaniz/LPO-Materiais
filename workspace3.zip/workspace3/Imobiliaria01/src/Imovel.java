import javax.swing.JOptionPane;

public class Imovel {

	//atributos
	private String proprietario;
	private String endereco;
	private double valorImovel;
	private double valorAluguel;
	private boolean aVenda;
	private boolean disponivel;
	private String cond;
	private String cond2;
	
	public Imovel(String proprietario, String endereco, double valorImovel, double valorAluguel, boolean aVenda,boolean disponivel, String cond, String cond2) {
		this.proprietario = proprietario;
		this.endereco = endereco;
		this.valorImovel = valorImovel;
		this.valorAluguel = valorAluguel;
		this.aVenda = aVenda;
		this.disponivel = disponivel;
		this.cond = cond;
		this.cond2 = cond2;
	}
	
	Imovel(){
		this.proprietario = "";
		this.endereco = "";
		this.valorImovel = 0.0;
		this.valorAluguel = 0.0;
		this.aVenda = true;
		this.disponivel = true;
		this.cond= "";
	}
	
	
	public String getProprietario() {
		return proprietario;
	}
	public void setProprietario(String proprietario) {
		this.proprietario = proprietario;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public double getValorImovel() {
		return valorImovel;
	}
	public void setValorImovel(double valorImovel) {
		if (valorImovel<0.0){ JOptionPane.showMessageDialog(null,"Valor negativo inserido em Valor do im�vel!");
		}
		else {this.valorImovel = valorImovel;
		}
	}
	public double getValorAluguel() {
		return valorAluguel;
	}
	public void setValorAluguel(double valorAluguel) {
		if (valorAluguel<0.0){ JOptionPane.showMessageDialog(null,"Valor negativo inserido em valor do aluguel!");
		}
		else {this.valorAluguel = valorAluguel;
		}
	}
	public boolean isaVenda(boolean aVenda) {	 
		return aVenda;
	}
	public void setaVenda(boolean aVenda) {
		this.aVenda= aVenda;
	}
	public boolean isDisponivel(boolean disponivel) {
		return disponivel;
	}
	public void setDisponivel(boolean disponivel) {
		this.disponivel= disponivel;
	}
	
	public String identificar() {
		
		if(aVenda) { cond="Sim";
		}
		else {
			cond="N�o";
		}
	
		
		if(disponivel) {
			cond2="Sim";
		}
		else {
				cond2="N�o";
			}

			
		return "Propriet�rio: " + this.proprietario + "\nA venda: " + this.cond + "\nDispon�vel: " + this.cond2;
	}
	
}
