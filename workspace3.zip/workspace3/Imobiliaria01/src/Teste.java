import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {
		
		Imovel i1 = new Imovel();
		
		i1.setProprietario("Beatriz");
		i1.setEndereco("Rua arco-�ris");
		i1.setValorImovel(-1);
		i1.setValorAluguel(-1);
		i1.setaVenda(false);
		i1.setDisponivel(true);
				
		JOptionPane.showMessageDialog(null, i1.identificar());
		

	}

}
