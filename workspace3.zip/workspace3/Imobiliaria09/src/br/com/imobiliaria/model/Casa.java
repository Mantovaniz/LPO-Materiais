package br.com.imobiliaria.model;

public class Casa extends Imovel{

		private boolean sobrado;
		private boolean condominio;
		
		
		public Casa(Cliente proprietario, String endereco, double valorImovel, double valorAluguel, boolean aVenda,
				boolean disponivel, String cond, String cond2, boolean sobrado, boolean condominio) {
			super();
			this.sobrado = sobrado;
			this.condominio = condominio;
		}
		
		public Casa() {
			this.sobrado = false;
			this.condominio = false;
		}
		
		
		public boolean isSobrado() {
			return sobrado;
		}

		public void setSobrado(boolean sobrado) {
			this.sobrado = sobrado;
		}

		public boolean isCondominio() {
			return condominio;
		}

		public void setCondominio(boolean condominio) {
			this.condominio = condominio;
		}
		

		public String identificar() {
			return "Nome do propriet�rio: " + this.getProprietario().getNome() + "\nA venda: " + (this.isaVenda() ? "Sim" : "N�o") + "\nDispon�vel: " + (this.isDisponivel() ? "Sim" : "N�o") + 
					"\nCondom�nio: " + (this.isCondominio() ? "Sim" : "N�o") ;
		}
		
		

	}
