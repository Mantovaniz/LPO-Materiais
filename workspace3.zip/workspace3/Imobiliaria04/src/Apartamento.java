
public class Apartamento extends Imovel {
	
	private int vagasGaragem;

	
	public Apartamento(Cliente proprietario, String endereco, double valorImovel, double valorAluguel, boolean aVenda,
			boolean disponivel, String cond, String cond2, int vagasGaragem) {
		this.vagasGaragem = vagasGaragem;
	}
	
	Apartamento() {
		this.vagasGaragem = 0;
	}


	public int getVagasGaragem() {
		return vagasGaragem;
	}
	public void setVagasGaragem(int vagasGaragem) {
		this.vagasGaragem = vagasGaragem;
	}
	
	
	public String identificar() {
		return "Nome do propriet�rio: " + this.getProprietario().getNome()  + "\nA venda: " + (this.isaVenda() ? "Sim" : "N�o") + "\nDispon�vel: " + (this.isDisponivel() ? "Sim" : "N�o") +
				"\nVagas de garagem: " + this.getVagasGaragem();
	}
	
	

}
