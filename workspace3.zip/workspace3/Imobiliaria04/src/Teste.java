import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {
		
		Cliente cliente1 = new Cliente();
		
		cliente1.setNome("Jackson Wang");
		cliente1.setTelefone("19 38562031");
		cliente1.setEmail("TeamWang94@gmail.com");
		
		
		Casa c1 = new Casa();
		
		c1.setSobrado(true);
		c1.setCondominio(true);
		c1.getProprietario().setNome("Todoroki Shouto");
		c1.setaVenda(true);
		c1.setDisponivel(true);
		
		
		Apartamento a1 = new Apartamento();
		
		a1.setVagasGaragem(2);
		a1.getProprietario().setNome("Midoriya Izuku");
		a1.setaVenda(false);
		a1.setDisponivel(false);
		
		
		Rural r1 = new Rural();
		
		r1.getProprietario().setNome("Toshinori");
		r1.setaVenda(false);
		r1.setDisponivel(true);
		
		
		JOptionPane.showMessageDialog(null, c1.identificar() );
		JOptionPane.showMessageDialog(null, a1.identificar() );
		JOptionPane.showMessageDialog(null, r1.identificar() );

	}

}
