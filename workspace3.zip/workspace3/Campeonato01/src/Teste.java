import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {
		
		Atleta a1 = new Atleta();
		
		a1.setNome("Robson");
		a1.setIdade(19);
		a1.setAltura(0);
		a1.setPeso(0);
		a1.setSexo("Masculino");
		
		JOptionPane.showMessageDialog(null, a1.identificar());

	}

}
