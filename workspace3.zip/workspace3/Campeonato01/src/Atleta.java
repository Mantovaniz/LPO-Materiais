import javax.swing.JOptionPane;

public class Atleta {
	
	private String nome;
	private int idade;
	private double altura;
	private double peso;
	private String sexo;
	private String categ;
	
	public Atleta(String nome, int idade, double altura, double peso, String sexo) {
		this.nome = nome;
		this.idade = idade;
		this.altura = altura;
		this.peso = peso;
		this.sexo = sexo;
	}
	
	Atleta(){
		this.nome="";
		this.idade=0;
		this.altura=0.0;
		this.peso=0.0;
		this.sexo="";
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		if(idade==0 || idade<0) {JOptionPane.showMessageDialog(null,"Valor inv�lido inserido em: Idade!");}
		else {
			this.idade= idade;
		}
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		if(altura==0.0 || altura<0.0) {JOptionPane.showMessageDialog(null,"Valor inv�lido inserido em: Altura!");}
		else {
			this.altura = altura;
		}
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		if(peso==0.0 || peso<0.0) {JOptionPane.showMessageDialog(null,"Valor inv�lido inserido em: Peso!");}
		else {
			this.peso = peso;
		}
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	
	public String identificar() {
		
		if(idade<=10) {
			categ="Infantil";
		}
		else {
			if(idade>10 && idade<=15) {
				categ="Juvenil";
			}
			else {
				if(idade>15 && idade<=18) {
					categ="Junior";
				}
				else {
					if(idade>18 && idade<=45) {
						categ="Adulto";
					}
					else {
						if(idade>45 && idade<=60) {
							categ="S�nior";
						}
						else { categ="Master";}
					}
				}
			}	
		}
	
		return "Nome: " + this.nome + "\nIdade: " + this.idade + "\nCategoria: " + this.categ;
	}
	
	

}
