package br.com.imobiliaria.controller;

import java.io.IOException;

import br.com.imobiliaria.model.Usuario;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;

public class JFXPrincipalControle {

	private Stage palcoPrincipal;
	private Usuario usuarioLogado;
	
	public Stage getPalcoPrincipal() {
		return palcoPrincipal;
	}

	public void setPalcoPrincipal(Stage palcoPrincipal) {
		this.palcoPrincipal = palcoPrincipal;
	}
	
	public Usuario getUsuarioLogado() {
		return usuarioLogado;
	}

	public void setUsuarioLogado(Usuario usuarioLogado) {
		this.usuarioLogado = usuarioLogado;
	}

	@FXML Label lUsuarioLogado;
	@FXML MenuItem menuCliente;
	@FXML MenuItem menuFuncionario;
	@FXML MenuItem menuCasa;
	@FXML MenuItem menuApartamento;
	@FXML MenuItem menuSalaComercial;
	@FXML Button bSair;
	
	public String getlUsuarioLogado() {
		return lUsuarioLogado.getText();
	}

	public void setlUsuarioLogado(String lUsuarioLogado) {
		this.lUsuarioLogado.setText(lUsuarioLogado);
	}

	@FXML public void abrirCliente() {}

	@FXML public void abrirFuncionario() {}

	@FXML public void abrirCasa() throws IOException {
		
		Stage stage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/br/com/imobiliaria/view/JFXCasaLayout.fxml"));
		BorderPane nodeRoot =  loader.load();
		Scene scene = new Scene(nodeRoot);
		stage.setScene(scene);
		
		stage.initStyle(StageStyle.UNDECORATED);
		stage.setResizable(false);
		stage.centerOnScreen();
		stage.show();
		
	}

	@FXML public void abrirApartamento() {}

	@FXML public void abrirSalaComercial() {}

	@FXML public void sair() {
		System.exit(0);
	}

}
