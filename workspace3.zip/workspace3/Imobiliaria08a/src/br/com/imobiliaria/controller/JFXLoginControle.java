package br.com.imobiliaria.controller;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import br.com.imobiliaria.model.Cliente;
import br.com.imobiliaria.model.Funcionario;
import br.com.imobiliaria.model.Usuario;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class JFXLoginControle implements Initializable {

	Funcionario funcionario = new Funcionario("Allan", "allan_prm", "123");
	Cliente cliente = new Cliente("Carlos", "4444-3333", "carlao@email.com", "carlaojr", "321");

	private Usuario usuario;
	
	private Stage palcologin;
	
	public Stage getPalcoLogin() {
		return palcologin;
	}

	public void setPalcoLogin(Stage palcologin) {
		this.palcologin = palcologin;
	}
	
	@FXML PasswordField pfSenha;

	@FXML CheckBox chbFuncionario;

	@FXML Button bEntrar;

	@FXML Button bSair;
	
	@FXML TextField tfLogin;

	@FXML public void entrar() throws IOException {
		
		String nomeUsuario = "", senhaUsuario = "";
		String nomeInformado = "", senhaInformada = "";
		
		if(chbFuncionario.isSelected()) {
			usuario = funcionario;
		}else {
			usuario = cliente;
		}
	
		nomeUsuario = usuario.getLogin();
		senhaUsuario = usuario.getSenha();
		
		nomeInformado = tfLogin.getText();
		senhaInformada = pfSenha.getText();
		
		if(nomeInformado.equals(nomeUsuario) && senhaInformada.equals(senhaUsuario)) {
			
			Stage stage = new Stage();
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/br/com/imobiliaria/view/JFXPrincipalLayout.fxml"));
			BorderPane nodeRoot =  loader.load();
			Scene scene = new Scene(nodeRoot);
			
			JFXPrincipalControle principalControle = loader.getController();
			principalControle.setPalcoPrincipal(stage);
			principalControle.setUsuarioLogado(usuario);
			principalControle.setlUsuarioLogado("Usu�rio: " + usuario.getNome());
			
			stage.setScene(scene);
			stage.initStyle(StageStyle.UNDECORATED);
			stage.setResizable(false);
			stage.centerOnScreen();
			stage.show();
			
			this.getPalcoLogin().close();
			
			
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Login");
			alert.setHeaderText("Valida��o de Usu�rio");
			alert.setContentText("Login V�lido!");
			alert.showAndWait();
		}else {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Login");
			alert.setHeaderText("Valida��o de Usu�rio");
			alert.setContentText("Contato e/ou Senha N�o Encontrados!");
			alert.showAndWait();
		}
	}

	@FXML public void sair() {
		System.exit(0);
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
}
