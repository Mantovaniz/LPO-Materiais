package br.com.imobiliaria.controller;

import java.net.URL;
import java.util.ResourceBundle;

import br.com.imobiliaria.model.Casa;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ChoiceBox;

public class JFXCasaControle implements Initializable{
	
	Casa casa = new Casa();
	
	@FXML TextField tfproprietario;
	@FXML TextField tfendereco;
	@FXML TextField tfvalorimovel;
	@FXML TextField tfvaloraluguel;
	
	@FXML RadioButton rbvenda;
	@FXML RadioButton rbdisponivel;
	
	@FXML ChoiceBox<String> chbsobrado;
	@FXML ChoiceBox<String> chbcondominio;
	
	
	@FXML Button binserir;
	@FXML Button blimpar;
	@FXML Button bcarregar;
	@FXML Button bidentificar;
	@FXML Button bfechar;
	
	@FXML public void inserir() {
		casa.getProprietario().setNome((tfproprietario.getText()));
		casa.setEndere�o(tfendereco.getText());
		casa.setValorImovel(Double.parseDouble(tfvalorimovel.getText()));
		casa.setValorAluguel(Double.parseDouble(tfvaloraluguel.getText()));
		
		if(chbsobrado.getSelectionModel().getSelectedItem() == "Verdadeiro") {
			casa.setSobrado(true);
		}else {
			casa.setSobrado(false);
		}
		if(chbcondominio.getSelectionModel().getSelectedItem() == "Verdadeiro"){
			casa.setCondominio(true);
		}else {
			casa.setCondominio(false);
		}
		if (rbvenda.isSelected()) {
			casa.setaVenda(true);
		}else {
			casa.setaVenda(false);			
		}
		if (rbdisponivel.isSelected()) {
			casa.setDisponivel(true);
		}else {
			casa.setDisponivel(false);			
		}
	}
	
	@FXML public void carregar() {
		tfproprietario.setText(casa.getProprietario().getNome());
		tfendereco.setText(casa.getEndere�o());
		tfvalorimovel.setText(String.valueOf(casa.getValorImovel()));
		tfvaloraluguel.setText(String.valueOf(casa.getValorAluguel()));
		
		if(casa.isSobrado()) {
			chbsobrado.setValue("Verdadeiro");
		}else {
			chbsobrado.setValue("Falso");
		}
		if(casa.isCondominio()){
			chbcondominio.setValue("Verdadeiro");
		}else {
			chbcondominio.setValue("Falso");;
		}
		if(casa.isaVenda()) {
			rbvenda.setSelected(true);
		}else {
			rbvenda.setSelected(false);
		}
		if(casa.isDisponivel()) {
			rbdisponivel.setSelected(true);
		}else {
			rbdisponivel.setSelected(false);
		}
	}
	@FXML public void identificar() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Im�vel");
		alert.setHeaderText("Identifica��o");
		alert.setContentText(casa.Identificar());
		alert.showAndWait();
	}
	@FXML public void limpar() {
		tfproprietario.setText("");
		tfendereco.setText("");
		tfvalorimovel.setText("");
		tfvaloraluguel.setText("");
		chbsobrado.setValue("");
		chbcondominio.setValue("");
		rbdisponivel.setSelected(false);
		rbvenda.setSelected(false);
	}
	@FXML public void fechar() {
		System.exit(0);
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		chbcondominio.getItems().addAll("Verdadeiro","Falso");
		chbsobrado.getItems().addAll("Verdadeiro","Falso");
	}
}

