package br.com.imobiliaria.model;

public class Apartamento extends Imovel{

	private int vagasGaragem;

	
	public Apartamento() {
		super();
		this.vagasGaragem = 0;
	}
	public Apartamento(Cliente proprietario, String endere�o, double valorImovel,
			double valorAluguel, boolean aVenda, boolean disponivel, int vagasGaragem) {
		super(proprietario, endere�o, valorImovel, valorAluguel, aVenda, disponivel);
		this.vagasGaragem = vagasGaragem;
	}
	
	
	public int getVagasGaragem() {
		return vagasGaragem;
	}
	public void setVagasGaragem(int vagasGaragem) {
		this.vagasGaragem = vagasGaragem;
	}
	
	
	public String identificar() {
		String mensagem1;
		String mensagem2;
		if(this.isaVenda()) {
			mensagem1 = "o im�vel est� a venda";
		}else {
			mensagem1 = "o im�vel n�o est� a venda";
		}
		if(this.isDisponivel()) {
			mensagem2 = "o im�vel est� disponivel";
		}else {
			mensagem2 = "o im�vel n�o est� disponivel";
		}
		return this.getProprietario().getNome() + "" + mensagem1 + "" + mensagem2 + " e tem" + this.getVagasGaragem()+ " vagas na garagem.";
	}
}
