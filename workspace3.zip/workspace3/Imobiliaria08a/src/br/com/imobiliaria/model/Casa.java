package br.com.imobiliaria.model;

public class Casa extends Imovel{

	private boolean sobrado;
	private boolean condominio;
	
	
	public Casa() {
		super();
		this.sobrado = true;
		this.condominio = false;
	}
	public Casa(Cliente proprietario, String endere�o, double valorImovel,
			double valorAluguel, boolean aVenda, boolean disponivel, boolean condominio, boolean sobrado) {
		super( proprietario, endere�o, valorImovel, valorAluguel, aVenda, disponivel);
		this.sobrado = sobrado;
		this.condominio = condominio;
	}
	
	
	public boolean isSobrado() {
		return sobrado;
	}
	public void setSobrado(boolean sobrado) {
		this.sobrado = sobrado;
	}
	public boolean isCondominio() {
		return condominio;
	}
	public void setCondominio(boolean condominio) {
		this.condominio = condominio;
	}
	
	
public String Identificar(){
		
		String mensagem; 
		String mensagem2;
		
		mensagem = "Propriet�rio: " + this.getProprietario().getNome();
		mensagem2 = "";
		
		if(this.isaVenda()){
			mensagem = mensagem + "\nEst� a venda";
		}else{
			mensagem = mensagem + "\nN�o est� a venda";			
		}
		
		if(this.isDisponivel()){
			mensagem2 = mensagem2 + "\nIm�vel dispon�vel";
		}else{
			mensagem2 = mensagem2 + "\nIm�vel n�o est� dispon�vel";			
		}
		
		return mensagem + mensagem2;
	}
	
}
