package br.com.imobiliaria.model;

public class Corretor extends Funcionario {

	private int creci;
	private double comissao;
	
	public Corretor() {
		super();
		this.creci = 0;
		this.comissao = 0;
	}
	
	public Corretor(String nome, String login, String senha, int creci, double comissao) {
		super(nome, login, senha);
		this.creci = creci;
		this.comissao = comissao;
	}

	public int getCreci() {
		return creci;
	}

	public void setCreci(int creci) {
		this.creci = creci;
	}

	public double getComissao() {
		return comissao;
	}

	public void setComissao(double comissao) {
		this.comissao = comissao;
	}
	
	
}
