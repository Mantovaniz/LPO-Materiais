package br.com.imobiliaria.model;

public class SalaComercial extends Imovel{

	private boolean copa;
	private boolean condominio;
	
	
	public SalaComercial() {
		super();
		this.copa = false;
		this.condominio = true;
	}
	public SalaComercial(Cliente proprietario, String endere�o,
			double valorImovel, double valorAluguel, boolean aVenda, boolean disponivel, boolean condominio, boolean copa) {
		super(proprietario, endere�o, valorImovel, valorAluguel, aVenda, disponivel);
		this.copa = copa;
		this.condominio = condominio;
	}
	
	
	public boolean isCopa() {
		return copa;
	}
	public void setCopa(boolean copa) {
		this.copa = copa;
	}
	public boolean isCondominio() {
		return condominio;
	}
	public void setCondominio(boolean condominio) {
		this.condominio = condominio;
	}
	
	
	public String identificar() {
		String mensagem1;
		String mensagem2;
		String mensagem3;
		if(this.isaVenda()) {
			mensagem1 = "o im�vel est� a venda";
		}else {
			mensagem1 = "o im�vel n�o est� a venda";
		}
		if(this.isDisponivel()) {
			mensagem2 = "o im�vel est� disponivel";
		}else {
			mensagem2 = "o im�vel n�o est� disponivel";
		}if(this.isCopa()) {
			mensagem3 = "o im�vel tem uma copa";
		}else {
			mensagem3 = "o im�vel n�o tem uma copa";
		}
		return this.getProprietario().getNome() + "" + mensagem1 + "" + mensagem2 + "" + mensagem3+ ".";
	}
	
	
	
}
