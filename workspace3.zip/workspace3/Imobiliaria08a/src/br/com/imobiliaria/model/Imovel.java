package br.com.imobiliaria.model;
import javax.swing.JOptionPane;

abstract public class Imovel {
	
	private Cliente proprietario;
	private String endere�o;
	private double valorImovel;
	private double valorAluguel;
	private boolean aVenda;
	private boolean disponivel;
	
	
	public Imovel() {
		super();
		this.proprietario = new Cliente();
		this.endere�o = "";
		this.valorImovel = 0;
		this.valorAluguel = 0;
		this.aVenda = false;
		this.disponivel = true;
	}
	
	public Imovel(Cliente proprietario, String endere�o, double valorImovel,
			double valorAluguel, boolean aVenda, boolean disponivel) {
		super();
		this.proprietario = proprietario;
		this.endere�o = endere�o;
		this.valorImovel = valorImovel;
		this.valorAluguel = valorAluguel;
		this.aVenda = aVenda;
		this.disponivel = disponivel;
	}
   
	
	public Cliente getProprietario() {
		return proprietario;
	}
	public void setProprietario(Cliente proprietario) {
		this.proprietario  = proprietario;
	}
	public String getEndere�o() {
		return endere�o;
	}
	public void setEndere�o(String endere�o) {
		this.endere�o = endere�o;
	}
	public double getValorImovel() {
		return valorImovel;
	}
	public void setValorImovel(double valorImovel) {
		if(valorImovel >= 0){
			this.valorImovel = valorImovel;	
		}else{
			JOptionPane.showMessageDialog(null, "Informe valores positivos");
		}
	}
	public double getValorAluguel() {
		return valorAluguel;
	}
	public void setValorAluguel(double valorAluguel) {
		if(valorAluguel >= 0){
			this.valorAluguel = valorAluguel;	
		}else{
			JOptionPane.showMessageDialog(null, "Informe valores positivos");
		}
	}
	
	public boolean isaVenda() {
		return aVenda;
	}
	public void setaVenda(boolean aVenda) {
		this.aVenda = aVenda;
	}
	public boolean isDisponivel() {
		return disponivel;
	}
	public void setDisponivel(boolean disponivel) {
		this.disponivel = disponivel;
	}
	
	public String Identificar(){
		
		String mensagem; 
		String mensagem2;
		
		mensagem = "Propriet�rio: " + this.getProprietario().getNome();
		
		if(this.isaVenda()){
			mensagem = mensagem + "\nEst� a venda";
		}else{
			mensagem = mensagem + "\nN�o est� a venda";			
		}
		
		if(this.isDisponivel()){
			mensagem2 = mensagem + "\nIm�vel dispon�vel";
		}else{
			mensagem2 = mensagem + "\nIm�vel n�o est� dispon�vel";			
		}
		
		return "Propriet�rio: " + this.getProprietario().getNome() + mensagem + mensagem2;
	}
}