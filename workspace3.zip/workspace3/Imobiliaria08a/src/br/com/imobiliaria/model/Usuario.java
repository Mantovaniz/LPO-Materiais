package br.com.imobiliaria.model;

public interface Usuario {

	abstract public String getNome();
	abstract public void setNome(String nome);
	abstract public String getLogin();
	abstract public void setLogin(String login);
	abstract public String getSenha();
	abstract public void setSenha(String senha);
}
