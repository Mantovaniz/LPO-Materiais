import javax.swing.JOptionPane;


public class Teste {

	public static void main(String[] args) {
		
		Cliente cliente1 = new Cliente();
		
		cliente1.setNome("Park Jin-Young");
		cliente1.setTelefone("23452924");
		cliente1.setEmail("Beatriz@gmail.com");
		
		
		Imovel i1 = new Imovel();
		
		i1.setProprietario(cliente1);
		i1.setEndereco("Seul");
		i1.setValorImovel(2000.00);
		i1.setValorAluguel(400.00);
		i1.setaVenda(false);
		i1.setDisponivel(true);
		
		
		Corretor c1 = new Corretor();
		
		c1.setNome("Mark Tuan");
		c1.setCreci(1200);
		c1.setComissao(2500.0);
		
		
		Locacao l1 = new Locacao();
		
		l1.setLocatario(cliente1);
		l1.setImovel(i1);
		
		JOptionPane.showMessageDialog(null, l1.gerarRecibo(c1) );
	}

}
