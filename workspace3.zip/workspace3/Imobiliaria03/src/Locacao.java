
public class Locacao {

	private Cliente locatario;
	private Imovel imovel;
	
	
	public Locacao(Cliente locatario, Imovel imovel) {
		this.locatario = locatario;
		this.imovel = imovel;
	}
	
	Locacao() {
		this.locatario = new Cliente();
		this.imovel = new Imovel();
	}

	public Cliente getLocatario() {
		return locatario;
	}

	public void setLocatario(Cliente locatario) {
		this.locatario = locatario;
	}

	public Imovel getImovel() {
		return imovel;
	}

	public void setImovel(Imovel imovel) {
		this.imovel = imovel;
	}
	
	public double calcularComissao(Corretor corretor) {
		return (corretor.getComissao()/100) * imovel.getValorImovel();
	}
	

	public String gerarRecibo(Corretor corretor) {
		return "O corretor " + corretor.getNome() + 
				"\nReceber� a comiss�o de R$ " + calcularComissao(corretor) + 
				"\nReferente a loca��o do im�vel localizado em " + imovel.getEndereco() + 
				".\nDo propriet�rio: " + getImovel().getProprietario().getNome();
	}
}