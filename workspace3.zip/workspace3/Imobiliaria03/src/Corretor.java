
public class Corretor {

	private String nome;
	private int creci;
	private double comissao;
	
	public Corretor(String nome, int creci, double comissao) {
		this.nome = nome;
		this.creci = creci;
		this.comissao = comissao;
	}
	
	Corretor() {
		this.nome = "";
		this.creci = 0;
		this.comissao = 0.0;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getCreci() {
		return creci;
	}
	public void setCreci(int creci) {
		this.creci = creci;
	}
	public double getComissao() {
		return comissao;
	}
	public void setComissao(double comissao) {
		this.comissao = comissao;
	}

	public String calcularComissao() {
		// TODO Auto-generated method stub
		return calcularComissao();
	}
	

	
	
}
