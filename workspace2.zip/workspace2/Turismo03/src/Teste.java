import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {
		
		 Hotel h1 = new Hotel("Bates Motel", 5, 300.00);
		 
		 Itinerario i1 = new Itinerario("Avi�o", "S�o Paulo", "Vancouver", "Rio de Janeiro", "Ottawa", 4000.0);
		 
		 Pacote p1 = new Pacote();
		 
		 p1.setDescricao("Viagem em Fam�lia");
		 p1.setHotel(h1);
		 p1.setItinerario(i1);
		 p1.setTaxa(300.0);
		 
		 Promocao prom = new Promocao();
		 
		 
		 JOptionPane.showMessageDialog(null, p1.totalPacote() );
		 JOptionPane.showMessageDialog(null, prom.feriasEscolares(p1) );
	}

}