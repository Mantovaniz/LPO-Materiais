
public class Promocao {
	
	private Object getPacote;

	public String feriasEscolares(Pacote pacote) {
		return "Valor Original: " + pacote.totalPacote() + "\nValor com Desconto: " + ( pacote.totalPacote() - (pacote.totalPacote()*0.1));
	}

	private Object getPacote() {
		// TODO Auto-generated method stub
		return null;
	}

}
