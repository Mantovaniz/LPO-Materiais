package br.resistencia.model;

/**
 * @author Prof. Ralfe
 * @version �ltima atualiza��o: 20/08/2017
 */
public interface Usuario {

	abstract public String getNome();
	abstract public String getContato();
	abstract public String getSenha();
}



