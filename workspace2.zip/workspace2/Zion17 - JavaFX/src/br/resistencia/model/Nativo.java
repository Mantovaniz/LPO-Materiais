package br.resistencia.model;

/**
 * @author Prof. Ralfe
 * @version �ltima atualiza��o: 20/08/2017
 */
public class Nativo extends Pessoa implements Usuario {

	// Atributo
	private String funcao;
	
	// Construtores
	public Nativo() {
		super();
		this.funcao = "";
	}

	public Nativo(String nome, String contato, String senha, 
			      boolean programacao, boolean lutas, boolean armas,
			      String funcao) {
		super(nome, contato, senha, programacao, lutas, armas);

		this.funcao = funcao;
	}

	// M�todos de acesso
	public String getFuncao() {
		return funcao;
	}

	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}
	
	// Funcionalidades dos objetos

	// Sobrescrita obrigat�ria do m�todo identificar
	@Override	
	public String identificar() {
		return "Perfil:\n" + this.getPerfil().habilidades();
	}

}













