/**
 * @author Prof. Ralfe
 * @version �ltima atualiza��o: 18/07/2017
 */

package br.resistencia.controller;

import javax.swing.JOptionPane;

import br.resistencia.model.Agente;
import br.resistencia.model.BluePill;
import br.resistencia.model.RedPill;

public class Teste {

	public static void main(String[] args) {

		// Cria��o dos objetos
		RedPill redPill = new RedPill("Anderson");
		BluePill bluePill = new BluePill("Cypher");
		Agente agente = new Agente("Smith");
		
		// Passagem de dois objetos que implementam a Interface Migrante
		JOptionPane.showMessageDialog(null, Transicao.acessarPlataforma(redPill, "Matrix"));
		JOptionPane.showMessageDialog(null, Transicao.acessarPlataforma(agente, "Zion"));
	}
}
























