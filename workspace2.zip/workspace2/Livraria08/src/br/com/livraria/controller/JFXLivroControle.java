package br.com.livraria.controller;

import java.net.URL;
import java.util.ResourceBundle;

import br.com.livraria.model.Livro;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class JFXLivroControle implements Initializable{
	
	@FXML TextField tfDescricao;
	@FXML ComboBox <String> cbGenero;
	@FXML ComboBox <String> cbOrigem;
	@FXML ComboBox <String> cbFormato;
	@FXML TextField tfAutor;
	@FXML TextField tfEditora;
	@FXML TextField tfEdicao;
	@FXML TextField tfPrecoCusto;
	@FXML TextField tfPrecoVenda;
	@FXML Button bInserir;
	@FXML Button bLimpar;
	@FXML Button bCarregar;
	@FXML Button bSair;
	
	Livro l1 = new Livro();
	
	public void initialize (URL arg0, ResourceBundle arg1) {
		
		tfDescricao.setText(String.valueOf(l1.getDescricao()));
		cbGenero.getItems().addAll("Literatura", "Inform�tica", "Did�tico");
		cbOrigem.getItems().addAll("Nacional", "Importado"); 
		cbFormato.getItems().addAll("F�sico", "Digital"); 
		tfAutor.setText(String.valueOf(l1.getAutor()));
		tfEditora.setText(String.valueOf(l1.getEditora()));
		tfEdicao.setText(String.valueOf(l1.getEdicao()));
		tfPrecoCusto.setText(String.valueOf(l1.getPrecoCusto()));
		tfPrecoVenda.setText(String.valueOf(l1.calcularPrecoVenda()));
	}
	
	@FXML public void bInserir() {
		
		l1.setDescricao(tfDescricao.getText());
		l1.setGenero(cbGenero.getSelectionModel().getSelectedItem().toString());
		l1.setOrigem(cbOrigem.getSelectionModel().getSelectedItem().toString());
		l1.setFormato(cbFormato.getSelectionModel().getSelectedItem().toString());
		l1.setAutor(tfAutor.getText());
		l1.setEditora(tfEditora.getText());
		l1.setEdicao(Integer.parseInt(tfEdicao.getText()));
		l1.setPrecoCusto(Double.parseDouble(tfPrecoCusto.getText()));
		//l1.setcalcularPrecoVenda(Double.parseDouble(tfPrecoVenda.getText()));
		
	}

	@FXML public void bLimpar() {
		tfDescricao.setText("");
		cbGenero.setValue("");
		cbOrigem.setValue("");
		cbFormato.setValue("");
		tfAutor.setText("");
		tfEditora.setText("");
		tfEdicao.setText("");
		tfPrecoCusto.setText("");
		tfPrecoVenda.setText("");
	}

	@FXML public void bCarregar() {
		tfDescricao.setText(l1.getDescricao());
		cbGenero.setValue(l1.getGenero());
		cbOrigem.setValue(l1.getOrigem());
		cbFormato.setValue(l1.getFormato());
		tfAutor.setText(l1.getAutor());
		tfEditora.setText(l1.getEditora());
		tfEdicao.setText(String.valueOf(l1.getEdicao()));
		tfPrecoCusto.setText(String.valueOf(l1.getPrecoCusto()));
		tfPrecoVenda.setText(String.valueOf(l1.calcularPrecoVenda()));
	}
	
	@FXML public void identificar() {
		
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Livraria");
		alert.setHeaderText("Identifica��o");
		alert.setContentText(l1.identificar());
		alert.showAndWait();
	}
	
	@FXML public void bSair() {
		System.exit(0);
	}

}