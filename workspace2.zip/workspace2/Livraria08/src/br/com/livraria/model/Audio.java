package br.com.livraria.model;

public class Audio extends Produto {

	private String artista;
	private String gravadora;
	
	
	public Audio(String artista, String gravadora) {
		this.artista = artista;
		this.gravadora = gravadora;
	}
	
	public Audio() {
		this.artista = "";
		this.gravadora = "";
	}
	
	
	public String getArtista() {
		return artista;
	}
	public void setArtista(String artista) {
		this.artista = artista;
	}
	public String getGravadora() {
		return gravadora;
	}
	public void setGravadora(String gravadora) {
		this.gravadora = gravadora;
	}
	
	public String identificar() {
		return "Descri��o: " + this.getDescricao() + "\nArtista: " + this.getArtista() +
		"\nPre�o de custo: " + this.getPrecoCusto() + "\nPre�o de Venda: " + this.calcularPrecoVenda();
	}
	
	
}
