package com.livraria.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import com.livraria.model.Livro;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class JFXLivroControle implements Initializable{
	//Instanciando um objeto do tipo livro 
		Livro livro = new Livro();
	
	//Componentes do layout
	@FXML TextField tfDescricao;
	@FXML ComboBox<String> cbGenero;
	@FXML ComboBox<String> cbOrigem;
	@FXML ComboBox<String> cbFormato;
	@FXML TextField tfAutor;
	@FXML TextField tfEditora;
	@FXML TextField tfEdicao;
	@FXML TextField tfPrecoCusto;
	@FXML TextField tfPrecoVenda;
	@FXML Button bInserir;
	@FXML Button bLimpar;
	@FXML Button bCarregar;
	@FXML Button bSair;

	//Initialize importado da classe implementada Initializable, para inserir itens no ComboBox
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		//Incializando itens do ComboBox
		cbGenero.getItems().addAll("Literatura", "Inform�tica", "Did�tico");
		cbOrigem.getItems().addAll("Nacional", "Importado");
		cbFormato.getItems().addAll("Fisico", "Digital");
		
	}
	
	//Actions dos bot�es
	@FXML public void inserir() {
		//usando o set do model Livro, e atribuindo o valor atrav�s do m�todo getText() recuperando dos TextFields
		livro.setAutor(tfAutor.getText());
		livro.setDescricao(tfDescricao.getText());
		livro.setEditora(tfEditora.getText());
		livro.setEdicao(Integer.parseInt(tfEdicao.getText()));
		livro.setPrecoCusto(Double.parseDouble(tfPrecoCusto.getText()));
		//Recuperando item selecionado no ComboBox
		livro.setFormato(cbFormato.getSelectionModel().getSelectedItem().toString());
		livro.setGenero(cbGenero.getSelectionModel().getSelectedItem().toString());
		livro.setOrigem(cbOrigem.getSelectionModel().getSelectedItem().toString());
		tfPrecoVenda.setText(String.valueOf(livro.calcularPrecoVenda()));
	}
	
	@FXML public void limpar() {
		//M�todo clear() para limpar os TextFields
		tfAutor.clear();
		tfDescricao.clear();
		tfEditora.clear();
		tfEdicao.clear();
		tfPrecoCusto.clear();
		tfPrecoVenda.clear();
		//Para limpar os ComboBox utilizamos o m�todo setValue("");
		cbFormato.setValue("");
		cbOrigem.setValue("");
		cbGenero.setValue("");
	}
	
	@FXML public void carregar() {
		//Utilizamos um setText no valor do TextField, passando como parametro um get nos atributos de Livro
		tfAutor.setText(livro.getAutor());
		tfDescricao.setText(livro.getDescricao());
		tfEditora.setText(livro.getEditora());
		//� utilizado String.valueOf para converter numeros para string
		tfEdicao.setText(String.valueOf(livro.getEdicao()));
		tfPrecoCusto.setText(String.valueOf(livro.getPrecoCusto()));
		tfPrecoVenda.setText(String.valueOf(livro.calcularPrecoVenda()));
		//Para carregar os ComboBox utilizamos tambem o m�todo setValue("");
		cbFormato.setValue(livro.getFormato());
		cbOrigem.setValue(livro.getOrigem());
		cbGenero.setValue(livro.getGenero());
	}
	
	@FXML public void sair(){
		JFXPrincipalControle.getPalcoPrincipal().close();

	}

}
