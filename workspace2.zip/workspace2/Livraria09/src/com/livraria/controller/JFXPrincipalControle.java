package com.livraria.controller;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class JFXPrincipalControle {
	//Cria um atributo palcoPrincipal do tipo Stage
	private static Stage palcoPrincipal;
	@FXML Button btSair;
	@FXML Button btForm;

	public static Stage getPalcoPrincipal() {
		return palcoPrincipal;
	}

	public void setPalcoPrincipal(Stage palcoPrincipal) {
		this.palcoPrincipal = palcoPrincipal;
	}
	
	@FXML public void abrir() throws IOException{
		// Cria um novo palco
				Stage stage = new Stage();
				// Objeto FMXLLoader que carrega o arquivo fxml
				FXMLLoader loader = new FXMLLoader();
				// Carregamento o arquivo fxml
				loader.setLocation(getClass().getResource("/com/livraria/view/JFXLivroLayout.fxml"));
				// Cria��o do Layout Pane (gerenciador de layout), que ser� o node/n�/componente raiz, e vinculo com o arquivo fxml
				Pane node =  loader.load();
				// Atribui��o do componente a cena
				Scene scene = new Scene(node);
				// Atribui��o da cena ao novo palco
				stage.setScene(scene);

				// O objeto loader possui a refer�ncia da classe JFXNativoControle 
				JFXLivroControle livroControle = loader.getController();	
				// E acesso a seus m�todos.
				// A refer�ncia do palco criado � passada para posterior acesso (fechamento)
				
				// Retira a barra superior da janela (icone, titulo, minimizar, maximizar e fechar)
				stage.initStyle(StageStyle.UNDECORATED);
				// N�o permite o redimensionamento
				stage.setResizable(false);
				// Centraliza a apresenta��o
				stage.centerOnScreen();
				// Define o comportamento Modal (bloqueia os demais formul�rios enquanto ele estiver aberto)
				stage.initModality(Modality.WINDOW_MODAL);
				
				// Apresenta o formul�rio
				setPalcoPrincipal(stage);		
				getPalcoPrincipal().show();
		
	}
	
	@FXML public void sair() {
		System.exit(0);
	}

}
