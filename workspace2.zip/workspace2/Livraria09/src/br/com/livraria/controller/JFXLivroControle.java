package br.com.livraria.controller;

import java.net.URL;
import java.util.ResourceBundle;

import br.com.livraria.model.Livro;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class JFXLivroControle implements Initializable {

	Livro livro = new Livro();

	@FXML TextField tfDescricao;
	@FXML ComboBox <String> cbGenero;
	@FXML ComboBox <String> cbOrigem;
	@FXML ComboBox <String> cbFormato;
	@FXML TextField tfAutor;
	@FXML TextField tfEditora;
	@FXML TextField tfEdicao;
	@FXML TextField tfPrecoCusto;
	@FXML TextField tfPrecoVenda;
	@FXML Button bInserir;
	@FXML Button bLimpar;
	@FXML Button bCarregar;
	@FXML Button bSair;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		cbGenero.getItems().addAll("Literatura","Inform�tica","Did�tico");	
		cbOrigem.getItems().addAll("Nacional","Importado");
		cbFormato.getItems().addAll("F�sico","Digital");
	}

	@FXML public void inserir() {
		livro.setDescricao( tfDescricao.getText() );
		livro.setGenero( cbGenero.getSelectionModel().getSelectedItem().toString() );
		livro.setOrigem( cbOrigem.getSelectionModel().getSelectedItem().toString() );
		livro.setFormato( cbFormato.getSelectionModel().getSelectedItem().toString() );
		livro.setPrecoCusto( Double.parseDouble( tfPrecoCusto.getText() ) );
		livro.setAutor( tfAutor.getText() );
		livro.setEditora( tfEditora.getText() );
		livro.setEdicao( Integer.parseInt( tfEdicao.getText() ) );
		
		tfPrecoVenda.setText( String.valueOf( livro.calcularPrecoVenda() ) );
	}

	@FXML public void limpar() {
		tfDescricao.clear();
		cbGenero.setValue("");
		cbOrigem.setValue("");
		cbFormato.setValue("");
		tfPrecoCusto.clear();
		tfAutor.clear();
		tfEditora.clear();
		tfEdicao.clear();
	}

	@FXML public void carregar() {
		tfDescricao.setText( livro.getDescricao() );
		cbGenero.setValue( livro.getGenero() );
		cbOrigem.setValue( livro.getOrigem() );
		cbFormato.setValue( livro.getFormato() );
		tfPrecoCusto.setText( String.valueOf( livro.getPrecoCusto() ) );
		tfAutor.setText( livro.getAutor() );
		tfEditora.setText( livro.getEditora() );
		tfEdicao.setText( String.valueOf( livro.getEdicao() ) );	
		tfPrecoVenda.setText( String.valueOf( livro.calcularPrecoVenda() ) );
	}

	@FXML public void sair() {
		System.exit(0);
	}

}