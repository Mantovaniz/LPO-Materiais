package br.com.livraria.controller;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Inicial extends Application{
		
		public static void main(String[] args) {
			//Agora iremos carregar o m�todo start()
			launch(args);
			
		}

		@Override
		public void start(Stage primaryStage) throws Exception {
			//Primeiro passo cria��o de um objeto FXML 
			FXMLLoader loader = new FXMLLoader();
			
			//Iremos agora mapear nosso arquivo fxml atraves do m�todo setLocation
			loader.setLocation(getClass().getResource("/br/com/livraria/view/JFXPrincipalLayout.fxml"));
			
			//Criaremos o gerenciador de Layout, nodeRoot(ou n� raiz) do tipo Pane que ir� receber o arquivo fxml 
			Pane nodeRoot = loader.load();
			
			//Criamos um objeto scene (ou cena) do tipo Scene e atribuimos o nodeRoot a ele
			Scene scene = new Scene(nodeRoot);
			
			//Agora atribuiremos o objeto scene palco prim�rio (ou primaryStage do tipo Stage)
			primaryStage.setScene(scene);
			
			//Estiliza��o da interface 
			
			//Retirada da barra superior
			primaryStage.initStyle(StageStyle.UNDECORATED);
			
			//Tirando o redirecionamento 
			primaryStage.setResizable(false);
			
			//Centralizando o programa na tela 
			primaryStage.centerOnScreen();
			
			//Agora iremos exibir o palco atraves do m�todo show()
			primaryStage.show();
		}

}