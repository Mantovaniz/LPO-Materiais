package br.com.livraria.controller;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

	public class JFXPrincipalControle {
		private static Stage palcoPrincipal;
		@FXML Button btSair;
		@FXML Button btForm;
	
		public static Stage getPalcoPrincipal() {
			return palcoPrincipal;
		}
	
		public void setPalcoPrincipal(Stage palcoPrincipal) {
			this.palcoPrincipal = palcoPrincipal;
		}
		
		@FXML public void abrir() throws IOException{
					Stage stage = new Stage();
					FXMLLoader loader = new FXMLLoader();
					loader.setLocation(getClass().getResource("/br/com/livraria/view/JFXLivroLayout.fxml"));
					Pane node =  loader.load();
					Scene scene = new Scene(node);
					stage.setScene(scene);
	
					JFXLivroControle livroControle = loader.getController();	
					
					stage.initStyle(StageStyle.UNDECORATED);
					stage.setResizable(false);
					stage.centerOnScreen();
					stage.initModality(Modality.WINDOW_MODAL);
					
					setPalcoPrincipal(stage);		
					getPalcoPrincipal().show();
			
		}
		
		@FXML public void sair() {
			System.exit(0);
		}
	
	}
