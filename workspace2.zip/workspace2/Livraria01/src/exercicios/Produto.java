package exercicios;

public class Produto {
	
	//Atributos 
	public String descricao;
	public String genero;
	public String origem;
	public String formato;
	public Double precoCusto;
	
	
	//m�todos de acesso
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public String getOrigem() {
		return origem;
	}
	public void setOrigem(String origem) {
		this.origem = origem;
	}
	public String getFormato() {
		return formato;
	}
	public void setFormato(String formato) {
		this.formato = formato;
	}
	public Double getPrecoCusto() {
		return precoCusto;
	}
	public void setPrecoCusto(Double precoCusto) {
		this.precoCusto = precoCusto;
	}
	
	public String identificar() {
		return "Descri��o: " + this.getDescricao() + "\nG�nero: " + this.getGenero() + "\nFormato: " + this.getFormato();
	}
}
