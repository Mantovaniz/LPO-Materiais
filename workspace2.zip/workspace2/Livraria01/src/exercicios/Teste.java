package exercicios;

import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {

		Produto prod1 = new Produto();
		
		prod1.descricao = "Livro escrito pelo Rick Riordan, 500 p�ginas";
		prod1.genero = "Fic��o";
		prod1.formato = "E-book";
		prod1.origem="Brasil";
		prod1.precoCusto=23.0;

		JOptionPane.showMessageDialog(null, prod1.identificar());

	}

}
