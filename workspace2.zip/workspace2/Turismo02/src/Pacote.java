
public class Pacote {

	private String descricao;
	private Hotel hotel;
	private Itinerario itinerario;
	private double taxa;
	
	public Pacote(String descricao, Hotel hotel, Itinerario itinerario, double taxa) {
		this.descricao = descricao;
		this.hotel = hotel;
		this.itinerario = itinerario;
		this.taxa = taxa;
	}
	
	Pacote(){
		this.descricao = "";
		this.taxa = 0.0;
		this.hotel = new Hotel();
		this.itinerario= new Itinerario();
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public Itinerario getItinerario() {
		return itinerario;
	}

	public void setItinerario(Itinerario itinerario) {
		this.itinerario = itinerario;
	}

	public double getTaxa() {
		return taxa;
	}

	public void setTaxa(double taxa) {
		this.taxa = taxa;
	}
	
	
	public String identificar() {
		return "\nDescri��o do pacote: " + this.getDescricao() + "\nNome do Hotel: " + this.getHotel().getNome() + "\nMeio de Transporte: " + this.getItinerario().getMeioTransporte();
	}
	
	public Double totalPacote() {
		return this.getHotel().totalHospedagem() +  this.getItinerario().getValor() +  this.getTaxa();
	}
	
	public String valoresPacote() {
		totalPacote();
		return "\nTotal da hospedagem: " + this.getHotel().totalHospedagem() + "\nValor do itiner�rio: " + this.getItinerario().getValor() + "\nTaxa: " + this.getTaxa() + "\nTotal do Pacote: " + totalPacote() ;
	}
	
}
