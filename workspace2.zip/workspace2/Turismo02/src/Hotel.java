
public class Hotel {

	private String nome;
	private int diarias;
	private double valor;
	
	public Hotel(String nome, int diarias, double valor) {
		this.nome = nome;
		this.diarias = diarias;
		this.valor = valor;
	}
	
	Hotel(){
		this.nome = "";
		this.diarias = 0;
		this.valor = 0.0;
	}

	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getDiarias() {
		return diarias;
	}

	public void setDiarias(int diarias) {
		this.diarias = diarias;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
	
	
	public Double totalHospedagem() {
		
		return this.getDiarias() * this.getValor();
		
	}
}
