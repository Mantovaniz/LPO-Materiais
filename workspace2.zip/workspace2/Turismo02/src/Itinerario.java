
public class Itinerario {

	private String meioTransporte;
	private String origemIda;
	private String destinoIda;
	private String origemVolta;
	private String destinoVolta;
	private double valor;
	
	public Itinerario(String meioTransporte, String origemIda, String destinoIda, String origemVolta,
			String destinoVolta, double valor) {
		this.meioTransporte = meioTransporte;
		this.origemIda = origemIda;
		this.destinoIda = destinoIda;
		this.origemVolta = origemVolta;
		this.destinoVolta = destinoVolta;
		this.valor = valor;
	}
	
	Itinerario(){
		this.meioTransporte = "";
		this.origemIda = "";
		this.destinoIda = "";
		this.origemVolta = "";
		this.destinoVolta = "";
		this.valor = 0.0;
	}

	public String getMeioTransporte() {
		return meioTransporte;
	}

	public void setMeioTransporte(String meioTransporte) {
		this.meioTransporte = meioTransporte;
	}

	public String getOrigemIda() {
		return origemIda;
	}

	public void setOrigemIda(String origemIda) {
		this.origemIda = origemIda;
	}

	public String getDestinoIda() {
		return destinoIda;
	}

	public void setDestinoIda(String destinoIda) {
		this.destinoIda = destinoIda;
	}

	public String getOrigemVolta() {
		return origemVolta;
	}

	public void setOrigemVolta(String origemVolta) {
		this.origemVolta = origemVolta;
	}

	public String getDestinoVolta() {
		return destinoVolta;
	}

	public void setDestinoVolta(String destinoVolta) {
		this.destinoVolta = destinoVolta;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
	
	
	
	
}
