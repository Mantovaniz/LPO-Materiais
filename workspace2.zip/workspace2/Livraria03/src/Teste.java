import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {
		
		Livro l1 = new Livro();
		
		l1.setAutor("J.K Rowling");
		l1.setEditora("Bloomsbury Publishing Plc");
		l1.setEdicao(24);
		l1.setDescricao("Capa fosca");
		l1.setGenero("Fic��o e Fantasia");
		l1.setOrigem("Inglaterra");
		l1.setFormato("E-book");
		l1.setPrecoCusto(55.0);
		
		
		Audio a1 = new Audio();
		
		a1.setArtista("Jeon Jungkook");
		a1.setGravadora("Big Entretainment");
		a1.setDescricao("M�sica coreana"); // <3
		a1.setGenero("K-pop");
		a1.setOrigem("Cor�ia do Sul");
		a1.setFormato("M�sica");
		a1.setPrecoCusto(236.0);
		
		
		Video v1 = new Video();
		
		v1.setDiretor("Stan Lee");
		v1.setDescricao("Vingadores: Ultimato");
		v1.setGenero("Fic��o, a��o");
		v1.setOrigem("Estados Unidos");
		v1.setFormato("Filme");
		v1.setPrecoCusto(43.0);
		
		
		JOptionPane.showMessageDialog(null, l1.identificar() );
		JOptionPane.showMessageDialog(null, a1.identificar() );
		JOptionPane.showMessageDialog(null, v1.identificar() );


	}

}
