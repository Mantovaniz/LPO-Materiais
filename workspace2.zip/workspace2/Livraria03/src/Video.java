
public class Video extends Produto{
	
	private String diretor;

	
	public Video(String descricao, String genero, String origem, String formato, double precoCusto, String diretor) {
		this.diretor = diretor;
	}
	
	public Video() {
		this.diretor = "";
	}
	

	public String getDiretor() {
		return diretor;
	}
	public void setDiretor(String diretor) {
		this.diretor = diretor;
	}
	
	
	public String identificar() {
		return "Descri��o: " + this.getDescricao() + "\nOrigem: " + this.getOrigem() + "\nDiretor: " + this.getDiretor()+
				"\nPre�o de custo: " + this.getPrecoCusto() + "\nPre�o de Venda: " + this.calcularPrecoVenda();

	}
	
	

}
