import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {
		
		Pacote p1 = new Pacote();
		
		p1.setDescricao("Viagem em fam�lia");
		p1.setOrigem("Brasil");
		p1.setDestino("Nova Zel�ndia");
		p1.setDias(0);
		p1.setMeioTransporte("Avi�o");
		p1.setValor(0.0);
		
		JOptionPane.showMessageDialog(null, p1.identificar());

	}

}
