package zion;

public class Pessoa {
	
	//Atributos 
	private String nome;
	private int registro; 
	
	Pessoa(){
		this.registro=0;
		this.nome="";
	}
	
	public Pessoa(String nome, int registro) {
		this.nome = nome;
		this.registro = registro;
	}


	//metodos de acesso
	public String getNome() { 
		return nome;
	}
	public int getRegistro() {
		return registro;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setRegistro(int registro) {
		this.registro = registro;
	}

	public String identificar() {
		return "Nome: " + this.getNome() + "\nRegistro: " + this.getRegistro();
	}
	//Source-> generate getters and setters
	
}
