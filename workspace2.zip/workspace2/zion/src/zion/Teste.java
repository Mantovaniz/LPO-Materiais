package zion;

import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {
	
		Pessoa p1= new Pessoa("Jos�", 214); //ctrl+espa�o
		
		JOptionPane.showMessageDialog(null, p1.identificar());
	}

}
