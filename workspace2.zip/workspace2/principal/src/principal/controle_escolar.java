package principal;

import javax.swing.JOptionPane;

public class controle_escolar {

	public static void recuperacao() {
		
		double rec=0;
		
		rec= Double.parseDouble (JOptionPane.showInputDialog("Digite a nota da recupera��o: ")) ;
		
		if(rec>=6.0) { JOptionPane.showMessageDialog(null,"Aprovado na Recupera��o!");
		}
		else { JOptionPane.showMessageDialog(null,"Reprovado!");
		}
	}
	
	
	public static void main(String[] args) {

	double no1,no2,frequencia,media,rec=0, cont;
	
	do {frequencia= Double.parseDouble (JOptionPane.showInputDialog("Digite a frequ�ncia: "));
	
	if(frequencia>=75) {
		
		no1= Double.parseDouble (JOptionPane.showInputDialog("Digite a primeira nota: "));
		no2= Double.parseDouble (JOptionPane.showInputDialog("Digite a segunda nota: "));
		
		media=(no1+no2)/2;
		
		if(media>=6.0) {JOptionPane.showMessageDialog(null, "Aprovado!");
		}
		
		else { 
			recuperacao();
		}
		
	}
	else {JOptionPane.showMessageDialog(null, "Reprovado por frequ�ncia!");}
	
	cont = JOptionPane.showConfirmDialog(null, "Deseja verificar um aluno?", "N�meros", JOptionPane.YES_NO_OPTION);
	} 
	while(cont==0);
}
}