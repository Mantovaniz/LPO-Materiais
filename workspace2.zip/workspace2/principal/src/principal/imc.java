package principal;

import javax.swing.JOptionPane;

public class imc {
	
	public static void imc(double imc) {

		if(imc<18.5) {JOptionPane.showMessageDialog(null,"Abaixo do peso!");
		}
		if(imc>=18.5 && imc<25) {JOptionPane.showMessageDialog(null,"Peso Normal!");
		}
		if(imc>=25 && imc<=30) {JOptionPane.showMessageDialog(null,"Acima do peso!");
		}
		if(imc>30) {JOptionPane.showMessageDialog(null,"Obeso!");}
		
		
	}

	public static void main(String[] args) {
		
		int pessoas=0,op;
		double peso,altura,imc=0;

		
		do {
			pessoas++;
			
			peso= Double.parseDouble (JOptionPane.showInputDialog("Digite seu peso: "));
			altura= Double.parseDouble (JOptionPane.showInputDialog("Digite sua altura: "));
			
			imc=peso/(altura*altura);
			
			 imc(imc);
			 
			 op= JOptionPane.showConfirmDialog(null, "Deseja verificar mais uma pessoa?", "IMC", JOptionPane.YES_NO_OPTION);
		
		}
		while(pessoas<=50);
		
		JOptionPane.showMessageDialog(null, "N�mero de verifica��es atingido!");

	}

}
