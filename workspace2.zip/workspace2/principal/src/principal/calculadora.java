//Beatriz de Souza M. 2�MIA

package principal;

import javax.swing.JOptionPane;

public class calculadora {
	
	public static double media (double num1, double num2, double m) {
		m=(num1+num2)/2;
		return m;
	}
	
	public static void menor (double num1, double num2, double me) {
		if(num1>num2) { me=num2;
		}
		 else { if (num2>num1) {me=num1;}
		 		if(num1==num2) {JOptionPane.showMessageDialog(null, "N�meros Iguais");}
		 	  }
		
		JOptionPane.showMessageDialog(null,"Menor n�mero: "+me);
	}
	
	public static double diferenca (double num1, double num2, double d) {
		if(num1>num2) { d=num1-num2;
		}
		 else { if (num2>num1) {d=num2-num1;}
		 }
		
		return d;
	}
	
	public static void crescente (double num1, double num2, double c) {
		if(num1<num2) { JOptionPane.showMessageDialog(null, num1 + "," + num2);
		} else { JOptionPane.showMessageDialog(null, num2 + "," + num1);
		  }
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double num1,num2,m=0,me=0,d=0,c=0;
		int resultado,cont,op;
			
			do {
		
				num1= Double.parseDouble (JOptionPane.showInputDialog("Digite o primeiro n�mero"));
				num2= Double.parseDouble (JOptionPane.showInputDialog("Digite o segundo n�mero"));
		
				op = Integer.parseInt( JOptionPane.showInputDialog("1� Apresentar a m�dia aritm�tica dos n�meros.\n2� Apresentar o menor n�mero.\n3� Apresentar a diferen�a entre o maior e o menor n�mero.\n4� Apresentar os n�meros em ordem crescente."));

				switch (op) {
		
				case 1: JOptionPane.showMessageDialog(null, media(num1,num2,m) );
				break;
		
				case 2: menor(num1,num2,me);
				break;
		
				case 3: JOptionPane.showMessageDialog(null, media(num1,num2,d) );
				break;
		
				case 4: diferenca(num1,num2,d);
				break;
		
				default: JOptionPane.showMessageDialog(null,"Op��o inv�lida!");
				
				}
		
				cont = JOptionPane.showConfirmDialog(null, "Deseja executar novamente?", "N�meros", JOptionPane.YES_NO_OPTION);

			} while (cont==0);

}
}