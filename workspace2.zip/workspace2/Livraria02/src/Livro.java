
public class Livro extends Produto {

	private String autor;
	private String editora;
	private int edicao;
	
	
	public Livro(String descricao, String genero, String origem, String formato, double precoCusto, String autor,
			String editora, int edicao) {
		super(descricao, genero, origem, formato, precoCusto);
		this.autor = autor;
		this.editora = editora;
		this.edicao = edicao;
	}
	
	public Livro() {
		this.autor = "";
		this.editora = "";
		this.edicao = 0;
	}
	
	
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public String getEditora() {
		return editora;
	}
	public void setEditora(String editora) {
		this.editora = editora;
	}
	public int getEdicao() {
		return edicao;
	}
	public void setEdicao(int edicao) {
		this.edicao = edicao;
	}
	
	
	public String identificar() {
		return "Descri��o: " + this.getDescricao() + "\nAutor: " + this.getAutor();
	}
	
}
