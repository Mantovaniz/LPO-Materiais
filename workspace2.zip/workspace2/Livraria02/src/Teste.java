import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {
		
		Livro l1 = new Livro();
		
		l1.setAutor("Rick Riordan");
		l1.setEditora("Rocco");
		l1.setEdicao(23);
		l1.setDescricao("Capa fosca");
		l1.setGenero("Fic��o");
		l1.setOrigem("Estados Unidos");
		l1.setFormato("F�sico");
		l1.setPrecoCusto(52.0);
		
		
		Audio a1 = new Audio();
		
		a1.setArtista("Jay Park");
		a1.setGravadora("SM Entretainment");
		a1.setDescricao("M�sica coreana"); // <3
		a1.setGenero("K-pop");
		a1.setOrigem("Cor�ia do Sul");
		a1.setFormato("M�sica");
		a1.setPrecoCusto(234.0);
		
		
		Video v1 = new Video();
		
		v1.setDiretor("Steven Spielberg");
		v1.setDescricao("Jurassic Park");
		v1.setGenero("Fic��o Cient�fica");
		v1.setOrigem("Estados Unidos");
		v1.setFormato("Filme");
		v1.setPrecoCusto(40.0);
		
		
		JOptionPane.showMessageDialog(null, l1.identificar() );
		JOptionPane.showMessageDialog(null, a1.identificar() );
		JOptionPane.showMessageDialog(null, v1.identificar() );


	}

}
