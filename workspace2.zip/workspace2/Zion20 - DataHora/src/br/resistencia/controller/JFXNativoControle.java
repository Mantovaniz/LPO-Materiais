package br.resistencia.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import br.resistencia.model.Nativo;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class JFXNativoControle implements Initializable {

	// Cria��o de um objeto Nativo
	Nativo nativo = new Nativo();

	// Atributo
	private Stage palcoNativo;

	// Metodos de acesso ao atributo			
	public Stage getPalcoNativo() {
		return palcoNativo;
	}

	public void setPalcoNativo(Stage palcoNativo) {
		this.palcoNativo = palcoNativo;
	}

	// Componentes FXML
	@FXML TextField tfRegistro;
	@FXML TextField tfNome;
	@FXML TextField tfContato;
	@FXML PasswordField pfSenha;	
	@FXML ComboBox cbFuncao;
	@FXML CheckBox chbProgramacao;
	@FXML CheckBox chbLutas;
	@FXML CheckBox chbArmas;
	@FXML Button bInserir;
	@FXML Button bLimpar;
	@FXML Button bCarregar;
	@FXML Button bIdentificar;
	@FXML Button bFechar;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// Inicializa os items do ComboBox cbPermissao
		cbFuncao.getItems().addAll("Navegador","Piloto","Armeiro", "Programador");

		tfRegistro.setText(String.valueOf( nativo.getRegistro()));
	}	

	// M�todos para eventos FXML
	@FXML public void inserir() {

		try {
			nativo.setNome(tfNome.getText());
			nativo.setContato(tfContato.getText());
			// O m�todo setSenha possui uma regra para inser��o
			// Se n�o for respeitada, retorna um objeto IOException
			nativo.setSenha(pfSenha.getText().toString());
			nativo.setFuncao(cbFuncao.getSelectionModel().getSelectedItem().toString());

		} catch (IOException e) {

			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Erro de inser��o!");
			alert.setHeaderText("Tamanho da senha incorreto.");
			alert.setContentText("A senha deve conter no m�nimo 2 e no m�ximo 6 caracteres.");
			alert.showAndWait();		
		}

		if(chbProgramacao.isSelected()) {
			nativo.getPerfil().setProgramacao(true);	
		}else {
			nativo.getPerfil().setProgramacao(false);
		}

		if(chbArmas.isSelected()) {
			nativo.getPerfil().setArmas(true);;	
		}else {
			nativo.getPerfil().setArmas(false);;
		}

		if(chbLutas.isSelected()) {
			nativo.getPerfil().setLutas(true);	
		}else {
			nativo.getPerfil().setLutas(false);
		}

	}

	@FXML public void limpar() {
		tfNome.setText("");
		tfContato.setText("");
		pfSenha.setText("");
		cbFuncao.setValue("");
		chbProgramacao.setSelected(false);
		chbArmas.setSelected(false);
		chbLutas.setSelected(false);		
	}

	@FXML public void carregar() {
		tfNome.setText(nativo.getNome());
		tfContato.setText(nativo.getContato());
		pfSenha.setText(nativo.getSenha());
		cbFuncao.setValue(nativo.getFuncao());

		if(nativo.getPerfil().isProgramacao()) {
			chbProgramacao.setSelected(true);		
		}else {
			chbProgramacao.setSelected(false);
		}

		if(nativo.getPerfil().isArmas()) {
			chbArmas.setSelected(true);		
		}else {
			chbArmas.setSelected(false);
		}

		if(nativo.getPerfil().isLutas()) {
			chbLutas.setSelected(true);		
		}else {
			chbLutas.setSelected(false);
		}	

	}

	@FXML public void identificar() {

		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Nativo");
		alert.setHeaderText("Identifica��o");
		alert.setContentText(nativo.identificar());
		alert.showAndWait();
	}

	@FXML public void fechar() {
		this.getPalcoNativo().close();
	}

}







































