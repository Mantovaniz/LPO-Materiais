package br.resistencia.model;

import java.io.IOException;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

/**
 * @author Prof. Ralfe
 * @version �ltima atualiza��o: 19/07/2017
 */

// Classe abstrata
abstract public class Pessoa {

	// Atributos
	private int registro;
	private String nome;
	private String contato;
	private String senha;
	private Perfil perfil;

	private static int registroSequencial = 1;

	// Construtores
	public Pessoa() {
		this.registro = registroSequencial++;
		this.nome = "";
		this.contato = "";
		this.senha = "";
		this.perfil = new Perfil();
	}
	public Pessoa(String nome) {
		this.registro = registroSequencial++;
		this.nome = nome;
		this.contato = "";
		this.senha = "";
		this.perfil = new Perfil();
	}
	public Pessoa(String nome, String contato, String senha,
			boolean programacao, boolean lutas, boolean armas) {
		this.registro = registroSequencial++;
		this.nome = nome;
		this.contato = contato;
		this.senha = senha;
		this.perfil = new Perfil(programacao, lutas, armas);
	}

	// M�todos de acesso
	public int getRegistro() {
		return registro;
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getContato() {
		return contato;
	}
	public void setContato(String contato) {
		this.contato = contato;
	}
	public String getSenha() {
		return senha;
	}

	// Regra para inser��o de senha: 
	// No m�nimo 2 e no m�ximo 6 caracteres
	
	// Delega o tratamento da exce��o IOException para a classe que chama o m�todo setSenha
	public void setSenha(String senha) throws IOException{

		// Valida��o da regra de inser��o
		if (senha.length() >= 2 && senha.length() <= 6) {
			this.senha = senha;
		}else {		
			// Se a regra n�o for satisfeita cria um objeto de exce��o do tipo IOException
			throw new IOException();				
		}
	}

	public Perfil getPerfil() {
		return perfil;
	}
	public void setPerfil(Perfil perfil) {
		this.perfil = perfil;
	}	

	// Funcionalidades dos objetos

	/**
	 * M�todo obrigat�rio a todas as subclasses de Pessoa
	 * @return mensagem de identifica��o de acordo com as regras da subclasse
	 */
	abstract public String identificar();

}




























